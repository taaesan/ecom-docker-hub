export const environment = {
  production: true,
  API_URL: 'http://restapi:8080'
};
